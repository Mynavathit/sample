import React from 'react';

const cards = [

			{
				"title" : "TITLE HEADING1",
				"description":"Title description, Dec 7, 2017",
				"p_text1":"Welcome to this page",
				"p_text2":"Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
			},

			{
				"title" : "TITLE HEADING2",
				"description":"Title description, Sep 2, 2017",
				"p_text1":"Welcome to middle of this page",
				"p_text2":"Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
			},
		];
export default cards;